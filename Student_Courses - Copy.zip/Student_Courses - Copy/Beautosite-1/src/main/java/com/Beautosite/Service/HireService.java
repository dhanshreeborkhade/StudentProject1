package com.Beautosite.Service;


import com.Beautosite.dto.HireDto;
import com.Beautosite.dto.HiringResponse;

public interface HireService {
 public HireDto savedetails(HireDto hireDto);


}
