package com.Beautosite.Service;

import com.Beautosite.dto.BeautoSiteDto;
import com.Beautosite.dto.ResponseVe;

public interface BeautoSiteService {
	ResponseVe createBeautoSite(BeautoSiteDto dto);

}
