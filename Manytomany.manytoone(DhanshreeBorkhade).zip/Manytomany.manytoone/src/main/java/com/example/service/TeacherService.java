package com.example.service;

import java.util.List;

import com.example.model.Student;
import com.example.model.Teacher;

public interface TeacherService 
{


Teacher save(Teacher teacher);
List<Teacher> findByteacherId(int id);
public String removeteacherById(int id);


}
