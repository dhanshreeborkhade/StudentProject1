package com.example.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.model.Teacher;
import com.example.model.Student;
import com.example.service.TeacherService;
import com.example.service.StudentService;

@RestController

public class TeacherController {
		@Autowired 
	TeacherService teacherservice;
		@Autowired
		StudentService userservice;
    @RequestMapping(value="/saveteacher",method=RequestMethod.POST)
      public Teacher saveteacher(@RequestBody Teacher teacher)
      {
    	  Teacher tea=teacherservice.save(teacher);
    	  return teacher;
    }
    @GetMapping("/tea/{teacherid}")
    public List<Teacher> findTeacher(@PathVariable int id){
    	 return teacherservice.findByteacherId(id);
    }
    @PostMapping("/deleteteacher/{id}")
	public String DeleteTeacher(@PathVariable int id) {
		teacherservice.removeteacherById(id);
		return "Deleted Succesfully ";
	}
   
}
