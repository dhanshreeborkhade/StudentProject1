package com.example.ServiceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.model.Student;
import com.example.model.Teacher;
import com.example.repository.StudentRepository;
import com.example.repository.TeacherRepository;
import com.example.service.StudentService;
import com.example.service.TeacherService;



@Service
public class StudentServiceImpl implements StudentService 

{
	
	@Autowired
	StudentRepository sturepo;

	@Override
	public Student savestudent(Student student) {
		sturepo.save(student);
		return student;
	}
}

