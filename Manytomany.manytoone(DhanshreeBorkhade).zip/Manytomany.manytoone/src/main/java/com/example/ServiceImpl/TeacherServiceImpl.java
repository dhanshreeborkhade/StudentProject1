package com.example.ServiceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.model.Student;
import com.example.model.Teacher;
import com.example.repository.TeacherRepository;
import com.example.service.TeacherService;

@Service
public  class TeacherServiceImpl implements TeacherService {

	
	
	@Autowired 
	TeacherRepository teacherrepo;

	@Override
	public Teacher save(Teacher teacher) {
		teacherrepo.save(teacher);
		return teacher;
	}

	@Override
	public List<Teacher> findByteacherId(int id) {
		List<Teacher> list = teacherrepo.findById(id);
		return null;
	}

	

	@Override
	public String removeteacherById(int id) {
		teacherrepo.deleteById(id);
		return "deleted successfully";
	}

	

	

	}

	

	